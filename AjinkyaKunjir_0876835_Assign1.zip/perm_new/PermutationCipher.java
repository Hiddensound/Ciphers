import java.util.*;
import java.io.*;

public class PermutationCipher{
	public static void main (String [] args) {
		Scanner sc= new Scanner (System.in);
		String tej;
		System.out.println("Enter the plaintext you want to encrypt: ");
		tej=sc.nextLine();
		System.out.println("Enter the size of key 'm': ");
		int m;
		String key="";
		String value="";
		m=sc.nextInt();

		int[] array = new int[m];
		int var=1;	 
		for(int i=0;i<m;i++){
			array[i]=var;
			var++;
		}
		int [] arrayRandiomized = new int[m];
		for(int i = 0; i<m; i++){
			arrayRandiomized[i]=array[i];
		}
		shuffleArray(arrayRandiomized);

		System.out.println("Type 'encrypt' and 'decrypt' as your preference:");
		String en;
		en=sc.next();
		if(en.equals("encrypt"))
		{
			try{
				//System.out.println("I am writing to txt file");
		PrintWriter writer = new PrintWriter("output_key.txt", "UTF-8");
	
		for(int i=0; i<m;i++){
			writer.print(array[i]);
		}
		writer.println();
		for(int i=0; i<m; i++){
			writer.print(arrayRandiomized[i]);
		}

		writer.close();
	}
	catch (Exception e){
		e.printStackTrace();
	}

	try{
			FileInputStream fin = new FileInputStream("output_key.txt");
			BufferedReader br = new BufferedReader(new InputStreamReader(fin));
			key = br.readLine();
			value = br.readLine();
			}
		catch(Exception e){
			e.printStackTrace();
			System.exit(0);
		}

			System.out.println("The encrypted plaintext is: ");
		EncryptPermutation ep = new EncryptPermutation();
		ep.Generator(key,value);
		ep.Encryptor(m,tej);
	}
	else{

		try{
			FileInputStream fin = new FileInputStream("output_key.txt");
			BufferedReader br = new BufferedReader(new InputStreamReader(fin));
			key = br.readLine();
			value = br.readLine();
		//System.out.println(key);
		//System.out.println(value);
		}
		catch(Exception e){
			//e.printStackTrace();
			System.out.println("Please encrypt before decrypting");
			System.exit(0);
		}


			System.out.println("The decrypted ciphertext is: ");
		DecryptPermutation dp = new DecryptPermutation();
		dp.Generator(key,value);
		dp.Decryptor(m,tej);
	}



	}
	static void shuffleArray(int[] ar)
  {
    
    Random rnd = new Random();
    for (int i = ar.length - 1; i > 0; i--)
    {
      int index = rnd.nextInt(i + 1);
      
      int a = ar[index];
      ar[index] = ar[i];
      ar[i] = a;
    }
  }


}