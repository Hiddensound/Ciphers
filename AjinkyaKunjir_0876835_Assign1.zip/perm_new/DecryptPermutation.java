import java.io.*;
import java.util.*;

public class DecryptPermutation{
	
	TreeMap <Integer,Integer> tmap= new TreeMap<Integer, Integer>();
	String key;
	String value;
	public void Generator(String key, String value){
		
		this.key=key;
		this.value=value;
		for (int i = 0; i<key.length();i++){
			tmap.put(Integer.parseInt(String.valueOf(key.charAt(i))), Integer.parseInt(String.valueOf(value.charAt(i))));
		}
	}

	public void Decryptor (int m, String str){
		
		String plaintext=Padding(m,str);
		String ciphertext="";
		String substrplaintext="";
		for(int i=0;i<plaintext.length();i=i+m){

			substrplaintext=plaintext.substring(i,i+m);
			
			for(int k=1; k<=m;k++){
				
			ciphertext=ciphertext+substrplaintext.charAt(tmap.get(k)-1);}
		
		}

		
		System.out.println(ciphertext);
	

	}


	public String Padding(int m,String str){
		int remainder = str.length()%m;
		if(remainder!=0){
			for(int k=1;k<=m-remainder;k++){
				str=str+" ";
			}
		}
		return str;
	}
}





