#include<stdio.h>
#include<string.h>
char *encryption(char[]);
char *decryption(char[]);
char alpha[29]={'a','b','c','d','e','f','g','h','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',',','.'};
char key[29];
void main()
{
	int i,key,choice,flag=0;
	char *c_text,msg[5000];
	printf("\nEnter the plain text to be encrypted:\n");
	scanf("%[^\n]",msg);
	printf("\nYour Entered Plain Text is:%s\n",msg);
	do {
			printf("\nPlease enter your choice\n1.Encryption\n2.Decryption\n3.press '0' for exit\n");
			scanf("%d",&choice);
		switch(choice)
		{
			case 1: 
				c_text=encryption(msg);
				flag=1;
				break;
			case 2:
				if(flag==1)
				decryption(c_text);
				else
					printf("First do the encryption process");
				break;
			case 0:
			break;
			default:
				printf("\nPlease enter an appropriate option before proceeding.\n");
				break;
		}
	}while(choice!=0);
}
char *encryption(char cipher_text[]){
	int i,val,j;
	printf("enter the Z29 unique characters for encryption(All 26 alphabets including [,./]):");
	scanf("%s",key);
	printf("\nGraphical Representation of Characters Replaced\n");
	printf("\nabcdefghijklmnopqrstuvwxyz,./\n");
	printf("\n|||||||||||||||||||||||||||||\n");
	printf("\n%s\n",key);
	for(i=0;i<strlen(cipher_text);i++){
			for(j=0;j<29;j++)
			{
				if(alpha[j]==cipher_text[i]){
					cipher_text[i]=key[j];
					break;
				}
			}
		}
		printf("\nYour encrypted message is:%s",cipher_text);
		return cipher_text;
}
	char *decryption(char cipher_text[])
{
	int i,val,j;
	char cipher[255];
	strcpy(cipher,cipher_text);
	printf("\n decryption\n");
	printf("\nGraphical Representation of Characters Replaced\n");
	printf("\n%s\n",key);
	printf("\n|||||||||||||||||||||||||||||\n");
	printf("\nabcdefghijklmnopqrstuvwxyz,./\n");
	for(i=0;i<strlen(cipher);i++){
		for(j=0;j<29;j++){
			if(cipher[i]==key[j])
		 	{
		 		cipher[i]=alpha[j];
		 		break;
		 	
			 }
		}
	}
	printf("Your decrypted message is %s",cipher);	
	}
