import java.util.*;
import java.io.*;
import java.lang.*;

public class Vcipher {
	
	public static char getchar(int k){
		if(k<0){
			k=26+k+97;
		}
		else{
		    k=k+97;
		}
		return (char)(k);
	}
	
	public static void decrypt(String text,String key){
        String res = "";
        text = text.toUpperCase();
        for (int i = 0, j = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c < 'A' || c > 'Z') continue;
            res += (char)((c - key.charAt(j) + 26) % 26 + 'A');
            j = ++j % key.length();
        }
        System.out.println("Welcome to the Vignere Cipher Program");
        System.out.println("26 keys pop out Randomly..Keep an eye out for 'CRYPT'");
		System.out.println("Secret key for cipher: "+key);
        System.out.println("Plaintext as follows: "+res);
		System.out.println("***********************************************************************\n");
	}
	
	public static void main(String args[]){
	
	//Plaintext was given in the assignment pdf
	String input="cjnpkgrlilqwawbnuptgkerwxuzviaiiysxckwdntjawhqcutttvptewtrpgvcwlkkkgczafsihrimixukrwxrfmgfgkfxgukpjvvzmcmjvawbnuptgcicvxvkgczkekgcqbchvnrqhhwiadfrcyxgvzqqtuvbdguvttkccdpvvfphftamzxqwrtgukcelqlrxgvycwtncbjkkeerecjqihvrjzpkkfexqgjtpjfupemswwxcjqxzpjtxkvlyaeaemwhovudkmnfxegfrwxtdyiaecyhlgjfpogymbxyfpzxxvpngkxfitnkfdniyrwxukssxpkqabmvkgcqbciagpadfrcyxgvyyimjvwpkgscwbpurwxqkftkorrwvnrqhxurlslgvjxmvccraceathhtfpmeygczwgutttvttkatmcvgiltwcsmjmvyghitfzaxodkbf";
	String ciphertext=input.toLowerCase();

	int m=2;
	int keylength=0;
	int maxic=0;
	
	int column=0;
	int row=0;
	char[][] original=new char[row][column];
	
	int ciphertextlength=ciphertext.length();
	
	int remainder=ciphertextlength%m;
	if(remainder!=0){
		for (int k=1; k<=m-remainder;k++){
			ciphertext=ciphertext+"*";
		}
	}
	

	
	while(true){
		if(m==7){
			break;
		}
	
		int rowsize=ciphertextlength/m;
	    int colsize=m;
		
		
		char[][] transpose =new char[colsize][rowsize];
		int stringindex1=0;
		for(int i=0;i<rowsize;i++){
			
			for(int j=0;j<colsize;j++){
				transpose[j][i]=ciphertext.charAt(stringindex1);
				stringindex1=stringindex1+1;
			}	
			
		}

		
        int flag=1;
		for(int i=0;i<colsize;i++){   
			int[] count=new int[26];
			int n=0;		
			for(int j=0;j<rowsize;j++){
				if(transpose[i][j]!='*'){			
				n=n+1;
				count[(int)transpose[i][j]-97]=count[(int)transpose[i][j]-97]+1;
				}
			}    
			
			double freqsum=0;

			for (int k=0;k<count.length;k++){
				
				freqsum=freqsum+(count[k]*(count[k]-1));
			}
			
			double ic=freqsum/(n*(n-1));
			if(ic<0.05 || ic>0.79){
				flag=0;
			}
			
			
		}

        if(flag==1){
			keylength=m;
			System.out.println("The length of key is "+String.valueOf(keylength)+" \n");
			original=new char[colsize][rowsize];
			column=rowsize;
			row=colsize;
			original=transpose;
			break;
		} 			
		m=m+1;
		
	}
	
	
	
	//END OF IC
	
	//START OF MIC
     
	String [] equations=new String[100];
	int equationsindex=0;
	for(int i=0;i<row;i++){
		int[] countx=new int[26];
		
		int n1=0;
       		
		for(int j=0;j<column;j++){
			if(original[i][j]!='*'){			
				n1=n1+1;
				countx[(int)original[i][j]-97]=countx[(int)original[i][j]-97]+1;
			}
		
		}
		
		
		for(int p=i+1;p<row;p++){

			double maxmcp=0;
			int g =0;
			int kj=0;
			int ki=0;
			for(int r=0;r<26;r++){
				
				int[] county=new int[26];
				int n2=0;
				for(int q=0;q<column;q++){
				if(original[p][q]!='*'){			
					n2=n2+1;
					char c=original[p][q];
					char sc=(char)(((int)c + r - 97) % 26 + 97);
					county[(int)sc-97]=county[(int)sc-97]+1;
				}				
									
				
				}
			
				double freqsum=0;


				for (int k=0;k<countx.length;k++){
					//System.out.println(count[k]);
					freqsum=freqsum+(countx[k]*county[k]);
					//System.out.println(freqsum);
				
				}
				double mic=freqsum/(n1*n2);
				//System.out.println(mic);
				if(maxmcp<mic){
					maxmcp=mic;
					g=r;
					ki=i;
					kj=p;
				}
				
			}
			
			equations[equationsindex]="K"+String.valueOf(ki)+"= K"+String.valueOf(kj)+"+"+String.valueOf(g);
			equationsindex=equationsindex+1;
			
		}
			
	}
	
	String[] keyarray=new String[26];
	for(int i=0;i<26;i++){
		String key="";
		int k0=i;
		key=key+getchar(k0);
		int k1=k0-11;
		key=key+getchar(k1);
		int k2=k0-4;
		key=key+getchar(k2);
		int k3=k0-13;
		key=key+getchar(k3);
		int k4=k0-9;
		key=key+getchar(k4);
	    //System.out.println(key);
		keyarray[i]=key;
		//break;
		
	}
	
	//System.out.println(keyarray.length);
	for(int i=0;i<keyarray.length;i++){
	//System.out.
	decrypt(ciphertext,keyarray[i].toUpperCase());
	}
	
	
	
	}	
}